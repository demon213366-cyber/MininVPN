# MiniN VPN v0.5

v0.5 establishes the real integration boundary with the existing Amnezia connection
controller without implementing a second VPN engine.

## What is wired
- MiniN UI can forward CONNECT/DISCONNECT intent to the host's existing controller.
- Connection state can be pushed back into MiniNHomeView.
- Session duration formatting is lifecycle-safe and does not poll the VPN engine.
- Traffic formatting is isolated from the UI.

## Host integration
In the existing Amnezia Activity/Fragment:
1. Create `MiniNHomeView`.
2. Construct `MiniNConnectionAdapter(existingConnectionController)`.
3. On the MiniN core click, call `adapter.toggle()`.
4. Feed the existing controller's connection-state observer into
   `adapter.pushState(connecting, connected)`.
5. Feed the selected Amnezia profile into `home.setServer(...)`.
6. Feed the existing statistics source into `home.setTraffic(...)`.

Do not replace the Amnezia VPN services with UI code. The existing VPN backend remains
responsible for tunneling, foreground service lifecycle, protocol implementations,
routing, DNS and configuration handling.

Because different Amnezia branches can expose different controller APIs, the adapter
uses a narrow compatibility boundary. The exact Activity/Fragment integration should
be compiled against the checked-out branch before release.
