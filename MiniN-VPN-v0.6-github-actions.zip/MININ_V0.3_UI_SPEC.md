# MiniN VPN v0.3 — Cyberpunk UI specification

Developer: Александр Минин

## Main screen
- Full dark cyberpunk presentation.
- Central animated tunnel core with CONNECT / CONNECTING / CONNECTED states.
- Server card with profile name, endpoint and protocol.
- Live session timer.
- Traffic cards for download/upload.
- Ping/status indicator.
- Import Amnezia profile action.
- Server/profile selector.
- Settings entry.

## UX
- The VPN engine remains the original Amnezia backend.
- UI state is driven by the existing connection controller rather than a second VPN implementation.
- Animations must run independently of packet processing.
- No busy polling loops; lifecycle-aware timers/observers only.
- Keep Android foreground VPN service behavior and notification behavior intact.

## v0.3 implementation target
1. Replace remaining legacy home-screen presentation where safe.
2. Add a dedicated MiniN home screen layer.
3. Bind connection state to the existing controller.
4. Bind session duration to connection lifecycle.
5. Add live byte counters using the existing traffic/statistics source when available.
6. Keep Amnezia config import and profile storage unchanged.
7. Preserve all existing VPN protocols and services.
