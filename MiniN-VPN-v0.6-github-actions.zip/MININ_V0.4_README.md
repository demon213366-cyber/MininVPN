# MiniN VPN v0.4

Cyberpunk home-screen layer for the Amnezia Android client.

### Important architecture
The MiniN UI does **not** implement a second VPN engine. Existing Amnezia connection services, profile/config handling, and protocol implementations remain the source of truth.

### Integration
Use `MiniNHomeView` from the existing Android Activity/Fragment and connect:
- the CONNECT action -> existing Amnezia `ConnectionController.connectButtonClicked()`;
- connection observer -> `setConnectionState(connecting, connected)`;
- selected profile -> `setServer(name, endpoint, protocol)`;
- existing traffic/statistics -> `setTraffic(download, upload, ping)`.

This keeps packet processing out of the UI thread and avoids polling loops.

### Build
Build with the original Amnezia project toolchain/Gradle setup after integrating the view into the existing home screen.
