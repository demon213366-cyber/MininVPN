package com.minin.vpn.ui

import android.os.SystemClock

/**
 * MiniN UI session model.
 * This class intentionally does not implement VPN networking.
 * It only represents presentation state supplied by the existing Amnezia controller.
 */
data class MiniNSessionUiState(
    val connected: Boolean = false,
    val connecting: Boolean = false,
    val serverName: String = "NO SERVER",
    val endpoint: String = "—",
    val protocol: String = "—",
    val pingMs: Long? = null,
    val downloadBytes: Long = 0,
    val uploadBytes: Long = 0,
    val connectedAtElapsed: Long? = null
) {
    fun elapsedSeconds(nowElapsed: Long = SystemClock.elapsedRealtime()): Long {
        val start = connectedAtElapsed ?: return 0L
        return if (connected) ((nowElapsed - start).coerceAtLeast(0L) / 1000L) else 0L
    }

    val statusLabel: String
        get() = when {
            connecting -> "ESTABLISHING TUNNEL"
            connected -> "TUNNEL ACTIVE"
            else -> "TUNNEL STANDBY"
        }
}
