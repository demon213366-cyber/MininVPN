package com.minin.vpn.ui

import android.os.Handler
import android.os.Looper
import java.lang.reflect.Method

/**
 * MiniN v0.5 adapter boundary.
 *
 * The host Activity/Fragment should provide the actual Amnezia ConnectionController
 * instance. The adapter only forwards connect/disconnect actions and exposes a small
 * state callback surface to the MiniN UI.
 *
 * Reflection is deliberately used here because Amnezia package/class names can vary
 * between branches. No VPN implementation is duplicated.
 */
class MiniNConnectionAdapter(
    private val controller: Any?,
    private val onState: (connecting: Boolean, connected: Boolean) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())

    fun toggle() {
        val c = controller ?: return
        // Prefer the public connectButtonClicked() entry used by the existing client.
        invokeIfPresent(c, "connectButtonClicked")
    }

    fun connect() {
        val c = controller ?: return
        invokeIfPresent(c, "connectButtonClicked")
    }

    fun disconnect() {
        val c = controller ?: return
        invokeIfPresent(c, "disconnect")
    }

    fun pushState(connecting: Boolean, connected: Boolean) {
        main.post { onState(connecting, connected) }
    }

    private fun invokeIfPresent(target: Any, name: String) {
        try {
            val m: Method? = target.javaClass.methods.firstOrNull {
                it.name == name && it.parameterTypes.isEmpty()
            }
            m?.isAccessible = true
            m?.invoke(target)
        } catch (_: Throwable) {
            // The host should log/report controller integration failures.
        }
    }
}
