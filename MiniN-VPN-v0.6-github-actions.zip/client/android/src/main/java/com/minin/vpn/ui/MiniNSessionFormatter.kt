package com.minin.vpn.ui

import android.os.SystemClock
import java.util.Locale

object MiniNSessionFormatter {
    fun duration(startElapsed: Long?, nowElapsed: Long = SystemClock.elapsedRealtime()): String {
        if (startElapsed == null) return "00:00:00"
        val total = ((nowElapsed - startElapsed).coerceAtLeast(0L) / 1000L)
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return String.format(Locale.US, "%02d:%02d:%02d", h, m, s)
    }

    fun bytesPerSecond(bytes: Long, seconds: Long): String {
        if (seconds <= 0) return "0 B/s"
        val value = bytes.toDouble() / seconds.toDouble()
        val units = arrayOf("B/s","KB/s","MB/s","GB/s")
        var v=value
        var i=0
        while(v>=1000 && i<units.lastIndex){ v/=1000; i++ }
        return if (v >= 100) String.format(Locale.US,"%.0f %s",v,units[i])
        else String.format(Locale.US,"%.1f %s",v,units[i])
    }
}
