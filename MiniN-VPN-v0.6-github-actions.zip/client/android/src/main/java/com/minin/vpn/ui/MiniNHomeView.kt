package com.minin.vpn.ui

import android.content.Context
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.widget.*
import kotlin.math.sin

/**
 * MiniN v0.4 cyberpunk home screen.
 *
 * Integration point:
 * - call setConnectionState(...) from the existing Amnezia connection controller/observer;
 * - call setServer(...) after the existing Amnezia profile is selected/imported;
 * - call setTraffic(...) from the existing traffic/statistics source.
 *
 * No VPN networking is implemented here.
 */
class MiniNHomeView(context: Context) : FrameLayout(context) {
    private val core = TunnelCoreView(context)
    private val status = TextView(context)
    private val server = TextView(context)
    private val stats = TextView(context)
    private var connectedAt = 0L

    init {
        setBackgroundColor(Color.rgb(5, 7, 14))

        addView(NeonBackground(context), LayoutParams(-1, -1))

        val column = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(28), dp(20), dp(20))
        }
        addView(column, LayoutParams(-1, -1))

        val title = TextView(context).apply {
            text = "MININ VPN"
            textSize = 30f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        column.addView(title, LinearLayout.LayoutParams(-1, dp(48)))

        val dev = TextView(context).apply {
            text = "DEVELOPER • АЛЕКСАНДР МИНИН"
            textSize = 11f
            setTextColor(Color.rgb(125, 210, 255))
            gravity = Gravity.CENTER
        }
        column.addView(dev, LinearLayout.LayoutParams(-1, dp(28)))

        column.addView(core, LinearLayout.LayoutParams(dp(250), dp(250)).apply {
            topMargin = dp(12)
            bottomMargin = dp(6)
        })

        status.apply {
            text = "TUNNEL STANDBY"
            textSize = 13f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(125, 210, 255))
        }
        column.addView(status, LinearLayout.LayoutParams(-1, dp(35)))

        server.apply {
            text = "NO SERVER  •  —"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
        }
        column.addView(server, LinearLayout.LayoutParams(-1, dp(42)))

        stats.apply {
            text = "↓ 0 B/s     ↑ 0 B/s     PING —"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(170, 180, 200))
        }
        column.addView(stats, LinearLayout.LayoutParams(-1, dp(34)))

        val import = button("IMPORT AMNEZIA")
        column.addView(import, LinearLayout.LayoutParams(-1, dp(52)).apply {
            topMargin = dp(8)
        })

        val servers = button("SERVERS / PROFILES")
        column.addView(servers, LinearLayout.LayoutParams(-1, dp(52)).apply {
            topMargin = dp(10)
        })

        core.setOnClickListener {
            // IMPORTANT: wire this click to the existing Amnezia connectButtonClicked()
            // from the host Activity/Fragment. This view deliberately has no VPN backend.
        }
    }

    fun setConnectionState(connecting: Boolean, connected: Boolean) {
        core.setState(connecting, connected)
        status.text = when {
            connecting -> "ESTABLISHING TUNNEL"
            connected -> "TUNNEL ACTIVE"
            else -> "TUNNEL STANDBY"
        }
        status.setTextColor(
            if (connected) Color.rgb(80, 255, 190)
            else Color.rgb(125, 210, 255)
        )
        if (connected && connectedAt == 0L) connectedAt = System.currentTimeMillis()
        if (!connected) connectedAt = 0L
    }

    fun setServer(name: String, endpoint: String, protocol: String) {
        server.text = "$name  •  $protocol\n$endpoint"
    }

    fun setTraffic(download: String, upload: String, ping: String) {
        stats.text = "↓ $download     ↑ $upload     PING $ping"
    }

    private fun button(label: String) = TextView(context).apply {
        text = label
        gravity = Gravity.CENTER
        textSize = 12f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.WHITE)
        background = GradientDrawable().apply {
            setColor(Color.argb(110, 20, 30, 55))
            setStroke(dp(1), Color.rgb(65, 160, 210))
            cornerRadius = dp(14).toFloat()
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private class NeonBackground(c: Context) : View(c) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private var phase = 0f
        init { setLayerType(View.LAYER_TYPE_SOFTWARE, null) }
        override fun onDraw(canvas: Canvas) {
            val w=width.toFloat(); val h=height.toFloat()
            p.shader=LinearGradient(0f,0f,w,h,Color.rgb(4,7,18),Color.rgb(13,5,22),Shader.TileMode.CLAMP)
            canvas.drawRect(0f,0f,w,h,p)
            p.shader=null
            p.color=Color.argb(55,50,170,220)
            p.strokeWidth=1f
            val step=dp(42)
            var x=0f
            while(x<w){ canvas.drawLine(x,0f,x,h,p); x+=step }
            var y=0f
            while(y<h){ canvas.drawLine(0f,y,w,y,p); y+=step }
            phase += .012f
            postInvalidateOnAnimation()
        }
        private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    }

    private class TunnelCoreView(c: Context) : View(c) {
        private val p=Paint(Paint.ANTI_ALIAS_FLAG)
        private var connecting=false
        private var connected=false
        private var phase=0f
        init { setLayerType(LAYER_TYPE_SOFTWARE,null) }
        fun setState(c:Boolean,a:Boolean){ connecting=c; connected=a; invalidate() }
        override fun onDraw(canvas:Canvas){
            val cx=width/2f; val cy=height/2f
            phase += if(connecting||connected) .055f else .012f
            val pulse=(sin(phase.toDouble())*0.5+0.5).toFloat()
            p.style=Paint.Style.STROKE
            p.strokeWidth=3f
            p.color=when {
                connected -> Color.rgb(70,255,190)
                connecting -> Color.rgb(255,80,190)
                else -> Color.rgb(80,190,255)
            }
            p.setShadowLayer(24f,0f,0f,p.color)
            canvas.drawCircle(cx,cy,78f+pulse*5f,p)
            p.strokeWidth=1.5f
            p.setShadowLayer(10f,0f,0f,p.color)
            canvas.drawCircle(cx,cy,98f+pulse*8f,p)
            p.style=Paint.Style.FILL
            p.setShadowLayer(30f,0f,0f,p.color)
            canvas.drawCircle(cx,cy,38f+pulse*3f,p)
            p.clearShadowLayer()
            p.color=Color.WHITE
            p.textAlign=Paint.Align.CENTER
            p.textSize=14f
            p.typeface=Typeface.DEFAULT_BOLD
            canvas.drawText(when {
                connected -> "DISCONNECT"
                connecting -> "CONNECTING"
                else -> "CONNECT"
            },cx,cy+5f,p)
            postInvalidateOnAnimation()
        }
    }
}
