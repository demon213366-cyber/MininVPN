package org.amnezia.vpn.protocol.wireguard

import android.util.Base64
import org.amnezia.vpn.protocol.BadConfigException
import org.amnezia.vpn.protocol.ProtocolConfig
import org.amnezia.vpn.util.net.InetEndpoint

private const val WIREGUARD_DEFAULT_MTU = 1280

open class WireguardConfig protected constructor(
    protocolConfigBuilder: ProtocolConfig.Builder,
    val endpoint: InetEndpoint,
    val persistentKeepalive: String?,
    val publicKeyHex: String,
    val preSharedKeyHex: String?,
    val privateKeyHex: String,
    val useProtocolExtension: Boolean,
    val jc: Int?,
    val jmin: Int?,
    val jmax: Int?,
    val s1: Int?,
    val s2: Int?,
    val s3: Int?,
    val s4: Int?,
    val h1: String?,
    val h2: String?,
    val h3: String?,
    val h4: String?,
    var i1: String?,
    var i2: String?,
    var i3: String?,
    var i4: String?,
    var i5: String?,
    val headerProtectionKeyHex: String?,
    val contentPaddingAddition: String?,
    val rekeyAfterTime: String?,
    val rekeyTimeout: String?,
    val rejectAfterTime: String?,
    val keepaliveTimeout: String?,
    val maxHandshakeAttempts: String?,
    val randomTrailers: String?,
    val disableCookies: String?,
) : ProtocolConfig(protocolConfigBuilder) {

    protected constructor(builder: Builder) : this(
        builder,
        builder.endpoint,
        builder.persistentKeepalive,
        builder.publicKeyHex,
        builder.preSharedKeyHex,
        builder.privateKeyHex,
        builder.useProtocolExtension,
        builder.jc,
        builder.jmin,
        builder.jmax,
        builder.s1,
        builder.s2,
        builder.s3,
        builder.s4,
        builder.h1,
        builder.h2,
        builder.h3,
        builder.h4,
        builder.i1,
        builder.i2,
        builder.i3,
        builder.i4,
        builder.i5,
        builder.headerProtectionKeyHex,
        builder.contentPaddingAddition,
        builder.rekeyAfterTime,
        builder.rekeyTimeout,
        builder.rejectAfterTime,
        builder.keepaliveTimeout,
        builder.maxHandshakeAttempts,
        builder.randomTrailers,
        builder.disableCookies,
    )

    fun toWgUserspaceString(): String = with(StringBuilder()) {
        appendDeviceLine(this)
        appendLine("replace_peers=true")
        appendPeerLine(this)
        return this.toString()
    }

    open fun appendDeviceLine(sb: StringBuilder) = with(sb) {
        appendLine("private_key=$privateKeyHex")
        if (useProtocolExtension) {
            validateProtocolExtensionParameters()
            appendLine("jc=$jc")
            appendLine("jmin=$jmin")
            appendLine("jmax=$jmax")
            appendLine("s1=$s1")
            appendLine("s2=$s2")
            s3?.let { appendLine("s3=$it") }
            s4?.let { appendLine("s4=$it") }
            appendLine("h1=$h1")
            appendLine("h2=$h2")
            appendLine("h3=$h3")
            appendLine("h4=$h4")
            i1?.let { appendLine("i1=$it") }
            i2?.let { appendLine("i2=$it") }
            i3?.let { appendLine("i3=$it") }
            i4?.let { appendLine("i4=$it") }
            i5?.let { appendLine("i5=$it") }
        }
        headerProtectionKeyHex?.takeIf { it.isNotEmpty() }?.let { appendLine("header_protection_key=$it") }
        contentPaddingAddition?.takeIf { it.isNotEmpty() }?.let { appendLine("content_padding_addition=$it") }
        rekeyAfterTime?.takeIf { it.isNotEmpty() }?.let { appendLine("rekey_after_time=$it") }
        rekeyTimeout?.takeIf { it.isNotEmpty() }?.let { appendLine("rekey_timeout=$it") }
        rejectAfterTime?.takeIf { it.isNotEmpty() }?.let { appendLine("reject_after_time=$it") }
        keepaliveTimeout?.takeIf { it.isNotEmpty() }?.let { appendLine("keepalive_timeout=$it") }
        maxHandshakeAttempts?.takeIf { it.isNotEmpty() }?.let { appendLine("max_handshake_attempts=$it") }
        randomTrailers?.takeIf { it.isNotEmpty() }?.let { appendLine("random_trailers=${it.toUapiBool()}") }
        disableCookies?.takeIf { it.isNotEmpty() }?.let { appendLine("disable_cookies=${it.toUapiBool()}") }
    }

    private fun validateProtocolExtensionParameters() {
        if (jc == null) throw BadConfigException("Parameter jc is undefined")
        if (jmin == null) throw BadConfigException("Parameter jmin is undefined")
        if (jmax == null) throw BadConfigException("Parameter jmax is undefined")
        if (s1 == null) throw BadConfigException("Parameter s1 is undefined")
        if (s2 == null) throw BadConfigException("Parameter s2 is undefined")
        if (h1 == null) throw BadConfigException("Parameter h1 is undefined")
        if (h2 == null) throw BadConfigException("Parameter h2 is undefined")
        if (h3 == null) throw BadConfigException("Parameter h3 is undefined")
        if (h4 == null) throw BadConfigException("Parameter h4 is undefined")
    }

    open fun appendPeerLine(sb: StringBuilder) = with(sb) {
        appendLine("public_key=$publicKeyHex")
        routes.filter { it.include }.forEach { route ->
            appendLine("allowed_ip=${route.inetNetwork}")
        }
        appendLine("endpoint=$endpoint")
        if (!persistentKeepalive.isNullOrEmpty() && persistentKeepalive != "0")
            appendLine("persistent_keepalive_interval=$persistentKeepalive")
        if (preSharedKeyHex != null)
            appendLine("preshared_key=$preSharedKeyHex")
    }

    open class Builder : ProtocolConfig.Builder(true) {
        internal lateinit var endpoint: InetEndpoint
            private set

        internal var persistentKeepalive: String? = null
            private set

        internal lateinit var publicKeyHex: String
            private set

        internal var preSharedKeyHex: String? = null
            private set

        internal lateinit var privateKeyHex: String
            private set

        override var mtu: Int = WIREGUARD_DEFAULT_MTU

        internal var useProtocolExtension: Boolean = false

        internal var jc: Int? = null
        internal var jmin: Int? = null
        internal var jmax: Int? = null
        internal var s1: Int? = null
        internal var s2: Int? = null
        internal var s3: Int? = null
        internal var s4: Int? = null
        internal var h1: String? = null
        internal var h2: String? = null
        internal var h3: String? = null
        internal var h4: String? = null
        internal var i1: String? = null
        internal var i2: String? = null
        internal var i3: String? = null
        internal var i4: String? = null
        internal var i5: String? = null
        internal var headerProtectionKeyHex: String? = null
        internal var contentPaddingAddition: String? = null
        internal var rekeyAfterTime: String? = null
        internal var rekeyTimeout: String? = null
        internal var rejectAfterTime: String? = null
        internal var keepaliveTimeout: String? = null
        internal var maxHandshakeAttempts: String? = null
        internal var randomTrailers: String? = null
        internal var disableCookies: String? = null

        fun setEndpoint(endpoint: InetEndpoint) = apply { this.endpoint = endpoint }

        fun setPersistentKeepalive(persistentKeepalive: String) = apply { this.persistentKeepalive = persistentKeepalive }

        fun setPublicKeyHex(publicKeyHex: String) = apply { this.publicKeyHex = publicKeyHex }

        fun setPreSharedKeyHex(preSharedKeyHex: String) = apply { this.preSharedKeyHex = preSharedKeyHex }

        fun setPrivateKeyHex(privateKeyHex: String) = apply { this.privateKeyHex = privateKeyHex }

        fun setUseProtocolExtension(useProtocolExtension: Boolean) = apply { this.useProtocolExtension = useProtocolExtension }

        fun setJc(jc: Int) = apply { this.jc = jc }
        fun setJmin(jmin: Int) = apply { this.jmin = jmin }
        fun setJmax(jmax: Int) = apply { this.jmax = jmax }
        fun setS1(s1: Int) = apply { this.s1 = s1 }
        fun setS2(s2: Int) = apply { this.s2 = s2 }
        fun setS3(s3: Int) = apply { this.s3 = s3 }
        fun setS4(s4: Int) = apply { this.s4 = s4 }
        fun setH1(h1: String) = apply { this.h1 = h1 }
        fun setH2(h2: String) = apply { this.h2 = h2 }
        fun setH3(h3: String) = apply { this.h3 = h3 }
        fun setH4(h4: String) = apply { this.h4 = h4 }
        fun setI1(i1: String) = apply { this.i1 = i1 }
        fun setI2(i2: String) = apply { this.i2 = i2 }
        fun setI3(i3: String) = apply { this.i3 = i3 }
        fun setI4(i4: String) = apply { this.i4 = i4 }
        fun setI5(i5: String) = apply { this.i5 = i5 }
        fun setHeaderProtectionKey(headerProtectionKeyHex: String) = apply { this.headerProtectionKeyHex = headerProtectionKeyHex }
        fun setContentPaddingAddition(contentPaddingAddition: String) = apply { this.contentPaddingAddition = contentPaddingAddition }
        fun setRekeyAfterTime(rekeyAfterTime: String) = apply { this.rekeyAfterTime = rekeyAfterTime }
        fun setRekeyTimeout(rekeyTimeout: String) = apply { this.rekeyTimeout = rekeyTimeout }
        fun setRejectAfterTime(rejectAfterTime: String) = apply { this.rejectAfterTime = rejectAfterTime }
        fun setKeepaliveTimeout(keepaliveTimeout: String) = apply { this.keepaliveTimeout = keepaliveTimeout }
        fun setMaxHandshakeAttempts(maxHandshakeAttempts: String) = apply { this.maxHandshakeAttempts = maxHandshakeAttempts }
        fun setRandomTrailers(randomTrailers: String) = apply { this.randomTrailers = randomTrailers }
        fun setDisableCookies(disableCookies: String) = apply { this.disableCookies = disableCookies }

        override fun build(): WireguardConfig = configBuild().run { WireguardConfig(this@Builder) }
    }

    companion object {
        inline fun build(block: Builder.() -> Unit): WireguardConfig = Builder().apply(block).build()
    }
}

@OptIn(ExperimentalStdlibApi::class)
internal fun String.base64ToHex(): String = Base64.decode(this, Base64.DEFAULT).toHexString()

/** Converts awg-quick on/off (and 0/1/true/false) to UAPI 1/0 for amneziawg-go ParseBool. */
internal fun String.toUapiBool(): String = when (trim().lowercase()) {
    "on", "1", "true", "t", "yes" -> "1"
    else -> "0"
}
