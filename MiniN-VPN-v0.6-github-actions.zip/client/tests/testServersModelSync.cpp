#include <QJsonDocument>
#include <QJsonObject>
#include <QUuid>
#include <QSignalSpy>
#include <QTest>

#include "utils/testCoreController.h"
#include "core/models/serverDescription.h"
#include "ui/models/serversModel.h"
#include "utils/testUtils.h"
#include "vpnConnection.h"
#include "secureQSettings.h"

using namespace amnezia;
using namespace amnezia::test;

class TestServersModelSync : public QObject
{
    Q_OBJECT

private:
    TestCoreController* m_coreController;
    SecureQSettings* m_settings;

private slots:
    void initTestCase() {
        QString testOrg = "AmneziaVPN-Test-" + QUuid::createUuid().toString();
        m_settings = new SecureQSettings(testOrg, "amnezia-client", nullptr, false);
        
        auto vpnConnection = QSharedPointer<VpnConnection>::create(nullptr, nullptr);
        m_coreController = new TestCoreController(vpnConnection, m_settings, nullptr, this);
    }

    void cleanupTestCase() {
        m_settings->clearSettings();
        delete m_coreController;
        delete m_settings;
    }

    void init() {
        m_settings->clearSettings();
        if (m_coreController->m_serversModel) {
            m_coreController->m_serversModel->updateModel(QVector<ServerDescription>(), QString{});
        }
    }

    void testServersModelSyncOnOperations() {
        QString awgKey = getEnvValue("THIRD_PARTY_AWG_VPN_KEY");

        if (!m_coreController->m_serversModel) {
            QSKIP("ServersModel not available");
        }

        if (!isEnvValueConfigured(awgKey)) {
            QSKIP("Set THIRD_PARTY_AWG_VPN_KEY");
        }

        QVERIFY2(m_coreController->m_serversModel->rowCount() == 0, "Initial model row count should be 0");

        auto importResult = m_coreController->m_importCoreController->extractConfigFromData(awgKey);
        m_coreController->m_importCoreController->importConfig(importResult.config);

        QVERIFY2(m_coreController->m_serversModel->rowCount() == 1, "Model should have 1 row after import");
        QString modelDesc1 = m_coreController->m_serversModel->data(m_coreController->m_serversModel->index(0, 0), ServersModel::NameRole).toString();
        QVERIFY2(modelDesc1 == "AWG Server", "Model should have correct server name");

        QVERIFY(m_coreController->m_serversController->renameServer(
            m_coreController->m_serversController->getServerId(0), QStringLiteral("Edited AWG Server")));

        QString modelDesc2 = m_coreController->m_serversModel->data(m_coreController->m_serversModel->index(0, 0), ServersModel::NameRole).toString();
        QVERIFY2(modelDesc2 == "Edited AWG Server", "Model should be updated after edit");

        m_coreController->m_serversController->removeServer(m_coreController->m_serversController->getServerId(0));
        QVERIFY2(m_coreController->m_serversModel->rowCount() == 0, "Model should have 0 rows after removal");
    }

    void testServersModelDefaultIndexSync() {
        QString awgKey = getEnvValue("THIRD_PARTY_AWG_VPN_KEY");
        QString xrayKey = getEnvValue("THIRD_PARTY_XRAY_VPN_KEY");
        QString wgKey = getEnvValue("THIRD_PARTY_WIRE_GUARD_VPN_KEY");

        if (!m_coreController->m_serversModel) {
            QSKIP("ServersModel not available");
        }

        if (!isEnvValueConfigured(awgKey) || !isEnvValueConfigured(xrayKey) || !isEnvValueConfigured(wgKey)) {
            QSKIP("Set THIRD_PARTY_AWG_VPN_KEY, THIRD_PARTY_XRAY_VPN_KEY, THIRD_PARTY_WIRE_GUARD_VPN_KEY");
        }

        auto importResult1 = m_coreController->m_importCoreController->extractConfigFromData(awgKey);
        m_coreController->m_importCoreController->importConfig(importResult1.config);
        auto importResult2 = m_coreController->m_importCoreController->extractConfigFromData(xrayKey);
        m_coreController->m_importCoreController->importConfig(importResult2.config);
        auto importResult3 = m_coreController->m_importCoreController->extractConfigFromData(wgKey);
        m_coreController->m_importCoreController->importConfig(importResult3.config);

        QVERIFY2(m_coreController->m_serversRepository->defaultServerIndex() == 2, "Default should be index 2");
        QVERIFY2(m_coreController->m_serversModel->rowCount() == 3, "Model should have 3 rows");

        bool isDefault0 = m_coreController->m_serversModel->data(m_coreController->m_serversModel->index(0, 0), ServersModel::IsDefaultRole).toBool();
        bool isDefault1 = m_coreController->m_serversModel->data(m_coreController->m_serversModel->index(1, 0), ServersModel::IsDefaultRole).toBool();
        bool isDefault2 = m_coreController->m_serversModel->data(m_coreController->m_serversModel->index(2, 0), ServersModel::IsDefaultRole).toBool();

        QVERIFY2(!isDefault0, "Server 0 should not be default");
        QVERIFY2(!isDefault1, "Server 1 should not be default");
        QVERIFY2(isDefault2, "Server 2 should be default");

        m_coreController->m_serversController->setDefaultServer(m_coreController->m_serversController->getServerId(0));

        isDefault0 = m_coreController->m_serversModel->data(m_coreController->m_serversModel->index(0, 0), ServersModel::IsDefaultRole).toBool();
        isDefault2 = m_coreController->m_serversModel->data(m_coreController->m_serversModel->index(2, 0), ServersModel::IsDefaultRole).toBool();

        QVERIFY2(isDefault0, "Server 0 should be default after change");
        QVERIFY2(!isDefault2, "Server 2 should not be default after change");
    }
};

QTEST_MAIN(TestServersModelSync)
#include "testServersModelSync.moc"

