#include <QDebug>
#include <QFile>
#include <QJsonDocument>
#include <QJsonObject>
#include <QProcessEnvironment>
#include <QSignalSpy>
#include <QTemporaryDir>
#include <QUuid>
#include <QTest>

#include "utils/testCoreController.h"
#include "core/models/serverDescription.h"
#include "secureQSettings.h"
#include "vpnConnection.h"

using namespace amnezia;

class TestUiAllowedDnsModelAndController : public QObject
{
    Q_OBJECT

private:
    TestCoreController *m_coreController;
    SecureQSettings *m_settings;

private slots:
    void initTestCase()
    {
        QString testOrg = "AmneziaVPN-Test-" + QUuid::createUuid().toString();
        m_settings = new SecureQSettings(testOrg, "amnezia-client", nullptr, false);

        auto vpnConnection = QSharedPointer<VpnConnection>::create(nullptr, nullptr);

        m_coreController = new TestCoreController(vpnConnection, m_settings, nullptr, this);
    }

    void cleanupTestCase()
    {
        m_settings->clearSettings();
        delete m_coreController;
        delete m_settings;
    }

    void init()
    {
        m_settings->clearSettings();
        if (m_coreController->m_serversModel) {
            m_coreController->m_serversModel->updateModel(QVector<ServerDescription>(), QString{});
        }
    }

    void testRolesAndSignals()
    {
        QSignalSpy finishedSpy(m_coreController->m_allowedDnsUiController, &AllowedDnsUiController::finished);
        QSignalSpy errorOccurredSpy(m_coreController->m_allowedDnsUiController, &AllowedDnsUiController::errorOccurred);

        QString ip = "188.40.167.81";

        m_coreController->m_allowedDnsUiController->addDns(ip);
        m_coreController->m_allowedDnsUiController->updateModel();
        QVERIFY2(errorOccurredSpy.count() == 0, "errorOccurred signal should not be emitted");
        QVERIFY2(finishedSpy.count() == 1, "finished signal should be emitted");
        QVERIFY2(m_coreController->m_allowedDnsModel->rowCount() == 1, "AllowedDnsModel should have 1 row");

        QModelIndex allowedDnsModelIndex = m_coreController->m_allowedDnsModel->index(0, 0);
        QVERIFY2(allowedDnsModelIndex.isValid(), "Site model index should be valid");

        auto dnsIp = m_coreController->m_allowedDnsModel->data(allowedDnsModelIndex, AllowedDnsModel::IpRole);
        QString msg = QString("dns ip should be %1, got %2").arg(ip, dnsIp.toString());
        QVERIFY2(dnsIp == ip, msg.toLocal8Bit().constData());

        QTemporaryDir tempDir;
        QVERIFY2(tempDir.isValid(), "Temporary directory should be created");

        const QString dnsFile = tempDir.filePath(QStringLiteral("dns.json"));
        {
            QFile file(dnsFile);
            QVERIFY2(file.open(QIODevice::WriteOnly), "DNS import file should be writable");
            file.write(R"(["8.8.8.8", "1.1.1.1"])");
        }

        m_coreController->m_allowedDnsUiController->importDns(dnsFile, true);
        m_coreController->m_allowedDnsUiController->updateModel();
        QVERIFY2(errorOccurredSpy.count() == 0, "errorOccurred signal should not be emitted");
        QVERIFY2(finishedSpy.count() == 2, "finished signal should be emitted");
        QVERIFY2(m_coreController->m_allowedDnsModel->rowCount() > 1, "AllowedDnsModel should have more than 1 row");

        const QString exportFile = tempDir.filePath(QStringLiteral("test_dns_export.json"));
        m_coreController->m_allowedDnsUiController->exportDns(exportFile);
        QVERIFY2(errorOccurredSpy.count() == 0, "errorOccurred signal should not be emitted");
        QVERIFY2(finishedSpy.count() == 3, "finished signal should be emitted");

        m_coreController->m_allowedDnsUiController->removeDns(0);
        m_coreController->m_allowedDnsUiController->updateModel();
        QVERIFY2(errorOccurredSpy.count() == 0, "errorOccurred signal should not be emitted");
        QVERIFY2(finishedSpy.count() == 4, "finished signal should be emitted");
        QVERIFY2(m_coreController->m_allowedDnsModel->rowCount() == 1, "AllowedDnsModel should have 1 row after removing first DNS");

        m_coreController->m_allowedDnsUiController->removeDns(0);
        m_coreController->m_allowedDnsUiController->updateModel();
        QVERIFY2(finishedSpy.count() == 5, "finished signal should be emitted");
        QVERIFY2(m_coreController->m_allowedDnsModel->rowCount() == 0, "AllowedDnsModel should have 0 rows");
    }
};

QTEST_MAIN(TestUiAllowedDnsModelAndController)
#include "testUiAllowedDnsModelAndController.moc"
