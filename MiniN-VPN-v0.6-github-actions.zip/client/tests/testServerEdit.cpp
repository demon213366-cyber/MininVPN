#include <QJsonDocument>
#include <QJsonObject>
#include <QUuid>
#include <QSignalSpy>
#include <QTest>

#include "utils/testCoreController.h"
#include "core/models/serverDescription.h"
#include "ui/models/serversModel.h"
#include "utils/testUtils.h"
#include "vpnConnection.h"
#include "secureQSettings.h"

using namespace amnezia;
using namespace amnezia::test;

class TestServerEdit : public QObject
{
    Q_OBJECT

private:
    TestCoreController* m_coreController;
    SecureQSettings* m_settings;

private slots:
    void initTestCase() {
        QString testOrg = "AmneziaVPN-Test-" + QUuid::createUuid().toString();
        m_settings = new SecureQSettings(testOrg, "amnezia-client", nullptr, false);
        
        auto vpnConnection = QSharedPointer<VpnConnection>::create(nullptr, nullptr);
        m_coreController = new TestCoreController(vpnConnection, m_settings, nullptr, this);
    }

    void cleanupTestCase() {
        m_settings->clearSettings();
        delete m_coreController;
        delete m_settings;
    }

    void init() {
        m_settings->clearSettings();
        m_coreController->m_serversRepository->invalidateCache();
        if (m_coreController->m_serversModel) {
            m_coreController->m_serversModel->updateModel(QVector<ServerDescription>(), QString{});
        }
    }

    void testServerEditTriggersHandlers() {
        QString awgKey = getEnvValue("THIRD_PARTY_AWG_VPN_KEY");

        if (!isEnvValueConfigured(awgKey)) {
            QSKIP("Set THIRD_PARTY_AWG_VPN_KEY");
        }

        QSignalSpy importFinishedSpy(m_coreController->m_importCoreController, &ImportController::importFinished);
        auto importResult = m_coreController->m_importCoreController->extractConfigFromData(awgKey);
        m_coreController->m_importCoreController->importConfig(importResult.config);
        QVERIFY2(importFinishedSpy.count() == 1, "Import should succeed");

        QSignalSpy serverEditedSpy(m_coreController->m_serversRepository, &SecureServersRepository::serverEdited);

        QVERIFY(m_coreController->m_serversController->renameServer(
            m_coreController->m_serversController->getServerId(0), QStringLiteral("Edited AWG Server")));

        QVERIFY2(serverEditedSpy.count() == 1, "serverEdited signal should be emitted");
        QVERIFY2(serverEditedSpy.at(0).at(0).toString() == m_coreController->m_serversRepository->serverIdAt(0),
                 "serverEdited should emit edited server id");

        const auto editedDescription = serverDescription(m_coreController->m_serversRepository,
                                                         m_coreController->m_serversRepository->serverIdAt(0));
        QVERIFY2(editedDescription.has_value(), "Server config should exist");
        QVERIFY2(*editedDescription == "Edited AWG Server", "Server description should be updated");

        if (m_coreController->m_serversModel) {
            QString modelDesc = m_coreController->m_serversModel->data(m_coreController->m_serversModel->index(0, 0), ServersModel::NameRole).toString();
            QVERIFY2(modelDesc == "Edited AWG Server", "Server description in model should be updated");
        }
    }

    void testServerEditPreservesDefault() {
        QString awgKey = getEnvValue("THIRD_PARTY_AWG_VPN_KEY");
        QString xrayKey = getEnvValue("THIRD_PARTY_XRAY_VPN_KEY");

        if (!isEnvValueConfigured(awgKey) || !isEnvValueConfigured(xrayKey)) {
            QSKIP("Set THIRD_PARTY_AWG_VPN_KEY and THIRD_PARTY_XRAY_VPN_KEY");
        }

        auto importResult1 = m_coreController->m_importCoreController->extractConfigFromData(awgKey);
        m_coreController->m_importCoreController->importConfig(importResult1.config);
        auto importResult2 = m_coreController->m_importCoreController->extractConfigFromData(xrayKey);
        m_coreController->m_importCoreController->importConfig(importResult2.config);

        QVERIFY2(m_coreController->m_serversRepository->defaultServerIndex() == 1, "Default server should be index 1");

        QSignalSpy defaultServerChangedSpy(m_coreController->m_serversRepository, &SecureServersRepository::defaultServerChanged);

        QVERIFY(m_coreController->m_serversController->renameServer(
            m_coreController->m_serversController->getServerId(1), QStringLiteral("Edited Default Server")));

        QVERIFY2(defaultServerChangedSpy.count() == 0, "defaultServerChanged should NOT be emitted when editing default server");
        QVERIFY2(m_coreController->m_serversRepository->defaultServerIndex() == 1, "Default server index should remain 1");

        QVERIFY(m_coreController->m_serversController->renameServer(
            m_coreController->m_serversController->getServerId(0), QStringLiteral("Edited Non-Default Server")));

        QVERIFY2(defaultServerChangedSpy.count() == 0, "defaultServerChanged should NOT be emitted when editing non-default server");
        QVERIFY2(m_coreController->m_serversRepository->defaultServerIndex() == 1, "Default server index should remain 1");
    }
};

QTEST_MAIN(TestServerEdit)
#include "testServerEdit.moc"

