#ifndef APIKEYS_H
#define APIKEYS_H

#include <QLatin1String>

namespace apiDefs
{
    namespace key
    {
        constexpr QLatin1String apiEndpoint("api_endpoint");
        constexpr QLatin1String apiKey("api_key");
        constexpr QLatin1String protocol("protocol");
        constexpr QLatin1String apiConfig("api_config");
        constexpr QLatin1String serviceType("service_type");
        constexpr QLatin1String serviceInfo("service_info");
        constexpr QLatin1String serviceProtocol("service_protocol");
        constexpr QLatin1String vpnKey("vpn_key");
        constexpr QLatin1String stackType("stack_type");
        constexpr QLatin1String cliVersion("cli_version");
        constexpr QLatin1String cliName("cli_name");
        constexpr QLatin1String availableCountries("available_countries");
        constexpr QLatin1String availableProtocols("available_protocols");
        constexpr QLatin1String installationUuid("installation_uuid");
        constexpr QLatin1String uuid("installation_uuid");
        constexpr QLatin1String osVersion("os_version");
        constexpr QLatin1String distribution("distribution");
        constexpr QLatin1String userCountryCode("user_country_code");
        constexpr QLatin1String serverCountryCode("server_country_code");
        constexpr QLatin1String serverCountryCodeL10n("server_country_code_l10n");
        constexpr QLatin1String serverCountryName("server_country_name");
        constexpr QLatin1String appVersion("app_version");
        constexpr QLatin1String authData("auth_data");

        constexpr QLatin1String aesKey("aes_key");
        constexpr QLatin1String aesIv("aes_iv");
        constexpr QLatin1String aesSalt("aes_salt");
        constexpr QLatin1String apiPayload("api_payload");
        constexpr QLatin1String keyPayload("key_payload");

        constexpr QLatin1String services("services");
        constexpr QLatin1String workerLastUpdated("worker_last_updated");
        constexpr QLatin1String lastDownloaded("last_downloaded");
        constexpr QLatin1String sourceType("source_type");
        constexpr QLatin1String appLanguage("app_language");
        constexpr QLatin1String locale("locale");

        constexpr QLatin1String captchaId("captcha_id");
        constexpr QLatin1String captchaSolution("captcha_solution");

        constexpr QLatin1String activeDeviceCount("active_device_count");
        constexpr QLatin1String maxDeviceCount("max_device_count");
        constexpr QLatin1String subscriptionEndDate("subscription_end_date");
        constexpr QLatin1String subscriptionExpiredByServer("subscription_expired_by_server");
        constexpr QLatin1String subscriptionStatus("subscription_status");
        constexpr QLatin1String subscription("subscription");
        constexpr QLatin1String endDate("end_date");
        constexpr QLatin1String issuedConfigs("issued_configs");
        constexpr QLatin1String subscriptionDescription("subscription_description");
        constexpr QLatin1String termsOfUseUrl("terms_of_use_url");
        constexpr QLatin1String privacyPolicyUrl("privacy_policy_url");

        constexpr QLatin1String supportInfo("support_info");
        constexpr QLatin1String email("email");
        constexpr QLatin1String billingEmail("billing_email");
        constexpr QLatin1String website("website");
        constexpr QLatin1String websiteName("website_name");
        constexpr QLatin1String telegram("telegram");

        constexpr QLatin1String id("id");
        constexpr QLatin1String orderId("order_id");
        constexpr QLatin1String transactionId("transaction_id");
        constexpr QLatin1String isTestPurchase("is_test_purchase");
        constexpr QLatin1String isInAppPurchase("is_in_app_purchase");
        constexpr QLatin1String config("config");

        constexpr QLatin1String isAdVisible("is_ad_visible");
        constexpr QLatin1String isRenewalAvailable("is_renewal_available");
        constexpr QLatin1String adHeader("ad_header");
        constexpr QLatin1String adDescription("ad_description");
        constexpr QLatin1String adEndpoint("ad_endpoint");

        constexpr QLatin1String configs("configs");

        constexpr QLatin1String updateAvailable("update_available");
        constexpr QLatin1String updateVersion("version");
        constexpr QLatin1String releaseDate("release_date");
        constexpr QLatin1String updateTags("tags");
        constexpr QLatin1String updateDescription("description");
        constexpr QLatin1String newFeatures("new_features");
        constexpr QLatin1String improvements("improvements");
        constexpr QLatin1String bugFixes("bug_fixes");
        constexpr QLatin1String downloadBaseUrl("download_base_url");
        constexpr QLatin1String releasePageUrl("release_page_url");

        constexpr QLatin1String publicKeyInfo("public_key");
        constexpr QLatin1String publicKey("public_key");
        constexpr QLatin1String expiresAt("expires_at");
        constexpr QLatin1String isConnectEvent("is_connect_event");
        constexpr QLatin1String certificate("certificate");
    } // namespace key
} // namespace apiDefs

#endif // APIKEYS_H
