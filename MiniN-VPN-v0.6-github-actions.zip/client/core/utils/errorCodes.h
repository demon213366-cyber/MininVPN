#ifndef ERRORCODES_H
#define ERRORCODES_H

#include <QMetaEnum>
#include <QObject>

namespace amnezia
{
    namespace error_code_ns
    {
      Q_NAMESPACE
      // TODO: change to enum class
      enum ErrorCode {
        // General error codes
        NoError = 0,
        UnknownError = 100,
        InternalError = 101,
        NotImplementedError = 102,
        AmneziaServiceNotRunning = 103,
        NotSupportedOnThisPlatform = 104,

        // Server errors
        ServerCheckFailed = 200,
        ServerPortAlreadyAllocatedError = 201,
        ServerContainerMissingError = 202,
        ServerDockerFailedError = 203,
        ServerCancelInstallation = 204,
        ServerUserNotInSudo = 205,
        ServerPacketManagerError = 206,
        ServerSudoPackageIsNotPreinstalled = 207,
        ServerUserDirectoryNotAccessible = 208,
        ServerUserNotAllowedInSudoers = 209,
        ServerUserPasswordRequired = 210,
        ServerDockerOnCgroupsV2 = 211,
        ServerCgroupMountpoint = 212,
        DockerPullRateLimit = 213,
        ServerLinuxKernelTooOld = 214,
        XrayServerConfigInvalid = 215,
        XrayServerNoVlessClients = 216,
        XrayRealityKeysReadFailed = 217,
        ServerContainerRuntimeNotSupported = 218,
        ContainerRuntimeServiceNotRunning = 219,

        // Ssh connection errors
        SshRequestDeniedError = 300,
        SshInterruptedError = 301,
        SshInternalError = 302,
        SshPrivateKeyError = 303,
        SshPrivateKeyFormatError = 304,
        SshTimeoutError = 305,

        // Ssh scp errors
        SshScpFailureError = 400,

        // Local errors
        OpenVpnConfigMissing = 500,
        OpenVpnManagementServerError = 501,

        // Distro errors
        OpenVpnExecutableMissing = 600,
        AmneziaServiceConnectionFailed = 603,
        ExecutableMissing = 604,
        XrayExecutableMissing = 605,
        Tun2SockExecutableMissing = 606,

        // VPN errors
        OpenVpnAdaptersInUseError = 700,
        OpenVpnUnknownError = 701,
        OpenVpnTapAdapterError = 702,
        AddressPoolError = 703,

        // 3rd party utils errors
        OpenSslFailed = 800,
        XrayExecutableCrashed = 803,
        Tun2SockExecutableCrashed = 804,

        // import and install errors
        ImportInvalidConfigError = 900,
        ImportOpenConfigError = 901,
        NoInstalledContainersError = 902,
        ImportBackupFileUseRestoreInstead = 903,
        RestoreBackupInvalidError = 904,
        LegacyApiV1NotSupportedError = 905,
        LegacyContainerNotSupportedError = 906,
        ConfigFormatVersionNotSupportedError = 907,
        RestoreBackupUnsupportedConfigsSkipped = 908,

        // Android errors
        AndroidError = 1000,

        // Api errors
        ApiConfigDownloadError = 1100,
        ApiConfigAlreadyAdded = 1101,
        ApiConfigEmptyError = 1102,
        ApiConfigTimeoutError = 1103,
        ApiConfigSslError = 1104,
        ApiMissingAgwPublicKey = 1105,
        ApiConfigDecryptionError = 1106,
        ApiServicesMissingError = 1107,
        ApiConfigLimitError = 1108,
        ApiNotFoundError = 1109,
        ApiUpdateRequestError = 1111,
        ApiSubscriptionExpiredError = 1112,
        ApiPurchaseError = 1113,
        ApiSubscriptionNotActiveError = 1114,
        ApiNoPurchasedSubscriptionsError = 1115,
        ApiTrialAlreadyUsedError = 1116,
        ApiCaptchaRequiredError = 1117,
        ApiCaptchaInvalidError = 1118,
        ApiCaptchaRefreshError = 1119,
        ApiRateLimitError = 1120,
        ApiNoPurchasesToRestore = 1121,
        ApiPurchasePendingError = 1122,

        // QFile errors
        OpenError = 1200,
        ReadError = 1201,
        PermissionsError = 1202,
        UnspecifiedError = 1203,
        FatalError = 1204,
        AbortError = 1205,

        // Billing errors
        BillingCanceled = 1300,
        BillingError = 1301,
        BillingGooglePlayError = 1302,
        BillingUnavailable = 1303,
        SubscriptionAlreadyOwned = 1304,
        SubscriptionUnavailable = 1305,
        BillingNetworkError = 1306,
      };
      Q_ENUM_NS(ErrorCode)
    }

    using ErrorCode = error_code_ns::ErrorCode;
}

Q_DECLARE_METATYPE(amnezia::ErrorCode)

#endif // ERRORCODES_H
